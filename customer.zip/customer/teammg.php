<!DOCTYPE HTML>
<html>
	<head>
		<title>Project rental</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="is-preload">
		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Header -->
				<header id="header">
					<div class="inner">

						<!-- Logo -->
							<a href="webe.php" class="logo">
								<span class="fa fa-car"></span> <span class="title">CAR RENTAL WEBSITE</span>
							</a>

						<!-- Nav -->
							<nav>
								<ul>
									<li><a href="#menu">Menu</a></li>
								</ul>
							</nav>

					</div>
				</header>

			<!-- Menu -->
				<nav id="menu">
					<h2>Menu</h2>
					<ul>
                        <li><a href="webe.php">Home</a></li>

                        <li><a href="fleete.php" >Fleet</a></li>

                        <li><a href="orders.php">Orders</a></li>

                        <li><a href="teame.html">Team</a></li>

					</ul>
				</nav>

				<!-- Main -->
					<div id="main">
						<div class="inner">
							<h1>Team</h1>

							<div class="image main">
								<img src="images/prosh.png" class="img-fluid" alt="" />
							</div>

							<div class="container">
								<div class="row">
									<div class="col-sm-3 text-center">
										<img src="images/tvtc.png" class="img-fluid" alt="" />

										<h2 class="m-n">Ali Alsaloom</h2>

										<p>
											MANAGER <br>


										</p>
									</div>

									<div class="col-sm-3 text-center">
										<img src="images/tvtc.png" class="img-fluid" alt="" />

										<h2 class="m-n">Ammar</h2>

										<p>
											Customer Support <br>

											
										</p>
									</div>

									<div class="col-sm-3 text-center">
										<img src="images/tvtc.png" class="img-fluid" alt="" />

										<h2 class="m-n">Abdulrahman</h2>

										<p>
											Social Media <br>

											
										</p>
									</div>

									<div class="col-sm-3 text-center">
										<img src="images/tvtc.png" class="img-fluid" alt="" />

										<h2 class="m-n">Mohammed</h2>

										database <br>

									</div>
								</div>
							</div>
						</div>
					</div>
					<table>
                                    <tr>
                                    <th>emp name</th>
                                    <th>job number</th>
                                    <th>Salary</th>
                                    <th>Username</th>
                                    <th>Password</th>
                                    </tr>
								<?php
                                $conn = mysqli_connect("localhost","root","","car rental office");
                                if ($conn-> connect_error){
                                    die("Connect Failed:". $conn-> connect_error);
                                }

                                $sql = "SELECT name_emp ,job_number , Salary, Username,password  from enployees";
                                $result = $conn-> query($sql);

                                if ($result-> num_rows > 0){
                                    while ($row = $result-> fetch_assoc()){
                                        echo 
                                        "<tr><td>". $row["name_emp"].
                                        "</td><td>". $row["job_number"].
                                        "</td><td>". $row["Salary"].
                                        "</td><td>".$row["Username"].
                                        "</td><td>".$row["password"].
                                        "</td><td>";
                                    }
                                    echo "</table>";
                                }
                                else{
                                    echo "0 result";
                                }
                                $conn-> close();
                                ?>
							

                                </table>
				<!-- Footer -->
					<footer id="footer">
						<div class="inner">
							<section>


								&nbsp;
							</section>


						</div>
					</footer>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/main.js"></script>
	</body>
</html>
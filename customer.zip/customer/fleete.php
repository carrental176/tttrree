<?php
    require('connect.php');


	if(isset($_POST["submit"])){
	$name_car = $_POST["name_car"];
	$pdate = $_POST["pdate"];
	$rdate = $_POST["rdate"];
	$Username = $_POST["Username"];
	$Phone = $_POST["Phone"];

	$query = "INSERT INTO booking VALUES('$name_car','$pdate','$rdate','$Username','$Phone','')";
    mysqli_query($conn,$query);
											
										

	}
	?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Project rental</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="is-preload">


		
		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Header -->
					<header id="header">
						<div class="inner">

							<!-- Logo -->
								<a href="webe.php" class="logo">
									<span class="fa fa-car"></span> <span class="title">CAR RENTAL WEBSITE</span>
								</a>

							<!-- Nav -->
								<nav>
									<ul>
										<li><a href="#menu">Menu</a></li>
									</ul>
								</nav>

						</div>
					</header>

				<!-- Menu -->
					<nav id="menu">
						<h2>Menu</h2>
						<ul>
							<li><a href="webe.php">Home</a></li>

							<li><a href="fleete.php" >Fleet</a></li>

                            <li><a href="orders.php">Orders</a></li>

							<li><a href="teame.html">Team</a></li>

						</ul>
					</nav>

				<!-- Main -->
					<div id="main">
						<div class="inner">
							<h1>Fleet</h1>

							<div class="image main">
								<img src="images/banner-image-7-1920x500.jpg" class="img-fluid" alt="" />
							</div>

							<!-- Fleet -->
							<section class="tiles">
								<article class="style1">
									<span class="image">
										<img src="images/2021-mazda-mazda6-carbon-edition-394-edit-1611709080.jpg" alt="" />
									</span>
									<a href="#footer" class="scrolly">
										<h2>Mazda 6 2021</h2>
										
										<p>price from: <strong> $ 140.00</strong> per weekend</p>

										<p>
											<i class="fa fa-user"></i> 5 &nbsp;&nbsp;
											<i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;
											<i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;
											<i class="fa fa-cog"></i> A
										</p>
									</a>
								</article>
								<article class="style2">
									<span class="image">
										<img src="images/2024-toyota-camry-102-64cbc4858e198.jpg" alt="" />
									</span>
									<a href="#footer" class="scrolly">
										<h2>camry 2024 le </h2>
										
										<p>price from: <strong> $ 140.00</strong> per weekend</p>

										<p>
											<i class="fa fa-user"></i> 5 &nbsp;&nbsp;
											<i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;
											<i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;
											<i class="fa fa-cog"></i> A
										</p>
									</a>
								</article>
								<article class="style3">
									<span class="image">
										<img src="images/20210802_01_02_W610_H407.jpg" alt="" />
									</span>
									<a href="#footer" class="scrolly">
										<h2>Land cruser</h2>
										
										<p>price from: <strong> $ 140.00</strong> per weekend</p>

										<p>
											<i class="fa fa-user"></i> 5 &nbsp;&nbsp;
											<i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;
											<i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;
											<i class="fa fa-cog"></i> A
										</p>
									</a>
								</article>

								<article class="style4">
									<span class="image">
										<img src="images/2023-bmw-m3-cs-first-drive-review.jpg" alt="" />
									</span>
									<a href="#footer" class="scrolly">
										<h2>BMW M3 2023 </h2>
										
										<p>price from: <strong> $ 140.00</strong> per weekend</p>

										<p>
											<i class="fa fa-user"></i> 5 &nbsp;&nbsp;
											<i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;
											<i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;
											<i class="fa fa-cog"></i> A
										</p>
									</a>
								</article>

								<article class="style5">
									<span class="image">
										<img src="images/bmw-m5-cs-onepager-gallery-m5-core-02-wallpaper.jpg" alt="" />
									</span>
									<a href="#footer" class="scrolly">
										<h2>BMW M5 2023 </h2>
										
										<p>price from: <strong> $ 140.00</strong> per weekend</p>

										<p>
											<i class="fa fa-user"></i> 5 &nbsp;&nbsp;
											<i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;
											<i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;
											<i class="fa fa-cog"></i> A
										</p>
									</a>
								</article>

								<article class="style6">
									<span class="image">
										<img src="images/11901df4cd5e3a5b923e1f20722f56a3.jpg" alt="" />
									</span>
									<a href="#footer" class="scrolly">
										<h2>MR C300 2023</h2>
										
										<p>price from: <strong> $ 140.00</strong> per weekend</p>

										<p>
											<i class="fa fa-user"></i> 5 &nbsp;&nbsp;
											<i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;
											<i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;
											<i class="fa fa-cog"></i> A
										</p>
									</a>
								</article>
							</section>
						</div>
					</div>

				<!-- Footer -->
					<footer id="footer">
						<div class="inner">
							<section>
								<h2>Book now</h2>
								<form method="post" action="#">
									

								
								
								
								<div class="fields">
										<div class="field half">
										<select id="name_car" name="name_car">
										<option value="camry">camry 2024</option>
										<option value="mazda 6">Mazda 6</option>
										<option value="bmw m3">BMW M3 2023</option>
										<option value="land cruser">land cruser</option>
										<option value="mr c300">mr c300</option>
										<option value="bmw m5">bmw m5</option>
									 </select>
										</div>

										<div class="field half">
											<input type="date" name="pdate" required value=""  placeholder="Pick-up date/time" />
										</div>

										<div class="field half">
											<input type="date" name="rdate" required value="" placeholder="Return date/tiem" />
										</div>

										<div class="field half">
											<input type="text" name="Username" required value="" placeholder="Username">
										</div>

										<div class="field half">
											<input type="text" name="Phone" required value="" placeholder="Phone" />
										</div>

										<div class="field text-right">
											<label>&nbsp;</label>

											
												
												<button type="submit" name="submit"  >submit</button>
											
										</div>
									</div>
								</form>
							</section>
							<section>
								<h2>Contact Info</h2>

								<ul class="alt">
									<li><span class="fa fa-envelope-o"></span> <a href="#">carrentalbus@gmail.com</a></li>
									<li><span class="fa fa-phone"></span>  +96658652393678</li>
									<li><span class="fa fa-map-pin"></span> king salman road , Al-Nahdah - 52356 - Al-Qassim - Burydah</li>
								</ul>

								
							</section>


						</div>
					</footer>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>